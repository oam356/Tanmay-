document.addEventListener('DOMContentLoaded', () => {
    const loanForm = document.getElementById('loanForm');
    const submitButton = document.getElementById('submitButton');
    const customerInfoButton = document.getElementById('customerInfoButton');
    const customerTableContainer = document.getElementById('customerTableContainer');
    let customerData = [];
    let numberCounter = 1;

    loanForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const customer = {
            number: numberCounter++,
            date: document.getElementById('date').value,
            customerName: document.getElementById('customerName').value,
            mobileNo: document.getElementById('mobileNo').value,
            pancardNo: document.getElementById('pancardNo').value,
            aadharCardNo: document.getElementById('aadharCardNo').value,
            emailId: document.getElementById('emailId').value,
            loanAmount: document.getElementById('loanAmount').value,
            loginCharge: document.getElementById('loginCharge').value,
            transId: document.getElementById('transId').value
        };

        // Add customer data to array
        customerData.push(customer);

        // Generate and save PDF receipt
        generateReceipt(customer);

        // Reset form
        loanForm.reset();

        // Show customer info
        displayCustomerInfo();
    });

    customerInfoButton.addEventListener('click', function() {
        displayCustomerInfo();
    });

    function displayCustomerInfo() {
        customerTableContainer.style.display = 'block';
        const table = document.createElement('table');
        table.innerHTML = `
            <thead>
                <tr>
                    <th>Number</th>
                    <th>Customer Name</th>
                    <th>Loan Amount</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                ${customerData.map((customer, index) => `
                    <tr>
                        <td>${customer.number}</td>
                        <td>${customer.customerName}</td>
                        <td>${customer.loanAmount}</td>
                        <td>
                            <button onclick="editCustomer(${index})">Edit</button>
                            <button onclick="deleteCustomer(${index})">Delete</button>
                        </td>
                    </tr>
                `).join('')}
            </tbody>
        `;
        customerTableContainer.innerHTML = '';
        customerTableContainer.appendChild(table);
    }

    window.editCustomer = function(index) {
        const customer = customerData[index];
        document.getElementById('number').value = customer.number;
        document.getElementById('date').value = customer.date;
        document.getElementById('customerName').value = customer.customerName;
        document.getElementById('mobileNo').value = customer.mobileNo;
        document.getElementById('pancardNo').value = customer.pancardNo;
        document.getElementById('aadharCardNo').value = customer.aadharCardNo;
        document.getElementById('emailId').value = customer.emailId;
        document.getElementById('loanAmount').value = customer.loanAmount;
        document.getElementById('loginCharge').value = customer.loginCharge;
        document.getElementById('transId').value = customer.transId;
        customerData.splice(index, 1);  // Remove customer from array
        displayCustomerInfo();  // Refresh table
    };

    window.deleteCustomer = function(index) {
        customerData.splice(index, 1);  // Remove customer from array
        displayCustomerInfo();  // Refresh table
    };

    function generateReceipt(customer) {
        const { jsPDF } = window.jspdf;
        const doc = new jsPDF();

        // Format the date to dd-mm-yyyy
        let finalDate = customer.date;
        if (!finalDate) {
            const today = new Date();
            const day = String(today.getDate()).padStart(2, '0');
            const month = String(today.getMonth() + 1).padStart(2, '0');
            const year = today.getFullYear();
            finalDate = `${day}-${month}-${year}`;
        } else {
            const originalDate = new Date(customer.date);
            const day = String(originalDate.getDate()).padStart(2, '0');
            const month = String(originalDate.getMonth() + 1).padStart(2, '0');
            const year = originalDate.getFullYear();
            finalDate = `${day}-${month}-${year}`;
        }

        // Draw outer border
        doc.setLineWidth(1.5);
        doc.rect(8, 8, 194, 280);

        // Inner border
        doc.setLineWidth(0.5);
        doc.rect(12, 12, 186, 272);

        // "Receipt" Title
        doc.setFontSize(22);
        doc.setTextColor(0, 102, 204);
        doc.text("Receipt", 105, 25, { align: "center" });

        // Grey Background for Header
        doc.setFillColor(230, 230, 230);
        doc.rect(14, 35, 182, 10, "F");

        doc.setFontSize(14);
        doc.setTextColor(0);
        doc.text("Customer Loan Details", 105, 42, { align: "center" });

        // Customer Details
        let startY = 55;
        const lineHeight = 10;

        const details = [
            { label: "Number", value: customer.number, bold: false },
            { label: "Date", value: finalDate, bold: false },
            { label: "Customer Name", value: customer.customerName, bold: false },
            { label: "Mobile No", value: customer.mobileNo, bold: false },
            { label: "Pancard No", value: customer.pancardNo, bold: false },
            { label: "Aadhar Card No", value: customer.aadharCardNo, bold: false },
            { label: "Email ID", value: customer.emailId, bold: false },
            { label: "Loan Amount", value: customer.loanAmount, bold: true }, // Bold Important
            { label: "Login Charge", value: customer.loginCharge, bold: true }, // Bold Important
            { label: "Transaction ID", value: customer.transId, bold: false },
        ];

        details.forEach(detail => {
            doc.setFontSize(12);
            if (detail.bold) {
                doc.setFont(undefined, 'bold'); // Set bold
            } else {
                doc.setFont(undefined, 'normal'); // Set normal
            }
            doc.text(`${detail.label}:`, 20, startY);
            doc.text(`${detail.value}`, 80, startY);
            startY += lineHeight;

            // Divider line
            doc.setDrawColor(180);
            doc.line(15, startY - 5, 195, startY - 5);
        });

        // Footer Note
        doc.setFontSize(10);
        doc.setTextColor(150);
        doc.setFont(undefined, 'normal');
        doc.text(
            "Note: This is Computer Generated Receipt. No Signature Required.",
            20,
            275
        );

        // Save PDF
        doc.save(`Receipt_${customer.customerName}_${customer.number}.pdf`);
    }
});
